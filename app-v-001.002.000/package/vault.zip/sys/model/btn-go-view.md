```meta-bind-button
label: view
icon: ""
style: default
class: ""
cssStyle: ""
backgroundImage: ""
tooltip: ""
id: btn-go-view
hidden: true
actions:
  - type: open
    link: view/view
    newTab: false

```