```meta-bind-button
label: conf
icon: ""
style: default
class: ""
cssStyle: ""
backgroundImage: ""
tooltip: ""
id: btn-go-conf
hidden: true
actions:
  - type: open
    link: pages/conf.md
    newTab: false

```