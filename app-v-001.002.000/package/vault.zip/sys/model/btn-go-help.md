```meta-bind-button
label: help
icon: ""
style: default
class: ""
cssStyle: ""
backgroundImage: ""
tooltip: ""
id: btn-go-help
hidden: true
actions:
  - type: open
    link: pages/help.md
    newTab: false

```