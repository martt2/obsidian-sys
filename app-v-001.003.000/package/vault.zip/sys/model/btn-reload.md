```meta-bind-button
label: reload
icon: ""
style: primary
class: ""
cssStyle: ""
backgroundImage: ""
tooltip: ""
id: btn-reload
hidden: true
actions:
  - type: inlineJS
    code: |-
      const {main} = await cJS()
      main.start()
    args: {}

```