```meta-bind-button
label: add-storage
icon: ""
style: default
class: ""
cssStyle: ""
backgroundImage: ""
tooltip: ""
id: btn-go-add-storage
hidden: true
actions:
  - type: open
    link: pages/form/add-storage.md
    newTab: false

```