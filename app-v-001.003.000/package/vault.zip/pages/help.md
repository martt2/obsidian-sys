# Help
---

Ir para: `BUTTON[btn-go-main]`

```meta-bind-embed
[[sys/model/btn-go-main]]
```