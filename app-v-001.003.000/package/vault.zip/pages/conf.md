
# Conf
---

**user:** `INPUT[text(placeholder(user)):user]`

`BUTTON[btn-reload]`

---

Ir para: `BUTTON[btn-go-main]`

```meta-bind-embed
[[sys/model/btn-reload]]
```

```meta-bind-embed
[[sys/model/btn-go-main]]
```
