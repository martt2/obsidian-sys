```meta-bind-button
label: main
icon: ""
style: default
class: ""
cssStyle: ""
backgroundImage: ""
tooltip: ""
id: btn-go-main
hidden: true
actions:
  - type: open
    link: main.md
    newTab: false

```