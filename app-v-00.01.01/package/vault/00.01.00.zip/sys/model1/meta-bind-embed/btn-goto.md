## Ir para

`BUTTON[btn-main]` `BUTTON[btn-view]`

```meta-bind-button
label: main
icon: ""
style: default
class: ""
cssStyle: ""
backgroundImage: ""
tooltip: ""
id: btn-main
hidden: true
actions:
  - type: open
    link: main.md
    newTab: false

```

```meta-bind-button
label: view
icon: ""
style: default
class: ""
cssStyle: ""
backgroundImage: ""
tooltip: ""
id: btn-view
hidden: true
actions:
  - type: open
    link: view/view
    newTab: false

```