# Conf
---

**user:** `INPUT[text(placeholder(user)):user]`

```meta-bind-embed
[[sys/model/meta-bind-embed/btn-goto]]
```