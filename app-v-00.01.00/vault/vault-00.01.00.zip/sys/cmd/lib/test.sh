#! /bin/bash

echo "---"
echo "$@"