#! /bin/bash

UUID=$1

rm $VAULT/work/$UUID