#! /bin/bash

UUID=$1

ln -s $STORAGE/data/$UUID $VAULT/work/$UUID