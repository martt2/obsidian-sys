#! /bin/bash

/usr/bin/obsidian --no-sandbox
